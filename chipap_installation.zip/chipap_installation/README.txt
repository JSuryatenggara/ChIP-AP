1. Install Anaconda 3. Skip this step if your computer already has Anaconda 3 installed.
2. Run chipap_installer.py via the command terminal. Use full path to call the script.
