export GEM_HOME=/opt/anaconda1anaconda2anaconda3/share/java/gem-2.7-0
